// // // frontend/src/AddModuleModal.js
// // import React, { useState } from 'react';
// // import {
// //   Dialog,
// //   DialogTitle,
// //   DialogContent,
// //   DialogActions,
// //   TextField,
// //   Button
// // } from '@mui/material';

// // export default function AddModuleModal({ open, onClose, onCreated }) {
// //   const [name, setName] = useState('');
// //   const [route, setRoute] = useState('');
// //   const [icon, setIcon] = useState('');

// //   const API = process.env.REACT_APP_API;

// //   const handleSubmit = () => {
// //     const payload = { name, route, icon };

// //     fetch(`${API}/modules`, {
// //       method: 'POST',
// //       headers: {
// //         'Content-Type': 'application/json',
// //         username: 'admin',
// //         password: 'admin'
// //       },
// //       body: JSON.stringify(payload)
// //     })
// //       .then(res => res.json())
// //       .then(() => {
// //         onCreated();      // Refresh module list
// //         onClose();        // Close modal
// //         setName('');
// //         setRoute('');
// //         setIcon('');
// //       });
// //   };

// //   return (
// //     <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth>
// //       <DialogTitle>Add New Global Module</DialogTitle>
// //       <DialogContent sx={{ display: 'flex', flexDirection: 'column', gap: 2, mt: 1 }}>
// //         <TextField
// //           label="Module Name"
// //           value={name}
// //           onChange={(e) => setName(e.target.value)}
// //           fullWidth
// //         />
// //         <TextField
// //           label="Route (e.g., /equipment)"
// //           value={route}
// //           onChange={(e) => setRoute(e.target.value)}
// //           fullWidth
// //         />
// //         <TextField
// //           label="Emoji Icon (e.g., 🎥)"
// //           value={icon}
// //           onChange={(e) => setIcon(e.target.value)}
// //           fullWidth
// //         />
// //       </DialogContent>
// //       <DialogActions>
// //         <Button onClick={onClose}>Cancel</Button>
// //         <Button onClick={handleSubmit} variant="contained" color="primary">
// //           Save
// //         </Button>
// //       </DialogActions>
// //     </Dialog>
// //   );
// // }


// import React, { useState, useEffect } from 'react';
// import {
//   Dialog, DialogTitle, DialogContent, DialogActions,
//   TextField, Button
// } from '@mui/material';

// export default function AddModuleModal({ open, onClose, onCreated, existing }) {
//   const [name, setName] = useState('');
//   const [route, setRoute] = useState('');
//   const [icon, setIcon] = useState('');
//   const API = process.env.REACT_APP_API;

//   useEffect(() => {
//     if (existing) {
//       setName(existing.name || '');
//       setRoute(existing.route || '');
//       setIcon(existing.icon || '');
//     } else {
//       setName('');
//       setRoute('');
//       setIcon('');
//     }
//   }, [existing]);

//   const handleSubmit = () => {
//     const payload = { name, route, icon };

//     const url = existing
//       ? `${API}/modules/${existing._id}`
//       : `${API}/modules`;

//     const method = existing ? 'PUT' : 'POST';

//     fetch(url, {
//       method,
//       headers: {
//         'Content-Type': 'application/json',
//         username: 'admin',
//         password: 'admin'
//       },
//       body: JSON.stringify(payload)
//     })
//       .then(res => res.json())
//       .then(() => {
//         onCreated();
//         onClose();
//       })
//       .catch(() => alert('Failed to save module'));
//   };

//   return (
//     <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth>
//       <DialogTitle>{existing ? 'Edit Module' : 'Add New Global Module'}</DialogTitle>
//       <DialogContent sx={{ display: 'flex', flexDirection: 'column', gap: 2, mt: 1 }}>
//         <TextField
//           label="Module Name"
//           value={name}
//           onChange={(e) => setName(e.target.value)}
//           fullWidth
//         />
//         <TextField
//           label="Route (e.g., /equipment)"
//           value={route}
//           onChange={(e) => setRoute(e.target.value)}
//           fullWidth
//         />
//         <TextField
//           label="Emoji Icon (e.g., 🎥)"
//           value={icon}
//           onChange={(e) => setIcon(e.target.value)}
//           fullWidth
//         />
//       </DialogContent>
//       <DialogActions>
//         <Button onClick={onClose}>Cancel</Button>
//         <Button onClick={handleSubmit} variant="contained" color="primary">
//           {existing ? 'Update' : 'Save'}
//         </Button>
//       </DialogActions>
//     </Dialog>
//   );
// }


import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Button
} from '@mui/material';

export default function AddModuleModal({ open, onClose, onCreated, existing }) {
  const [name, setName] = useState('');
  const API = process.env.REACT_APP_API;

  useEffect(() => {
    setName(existing?.name || '');
  }, [existing]);

  const generateRoute = (text) =>
    text.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9\-]/g, '');

  const handleSubmit = () => {
    const payload = {
      name,
      route: generateRoute(name)
    };

    const method = existing ? 'PUT' : 'POST';
    const url = existing
      ? `${API}/modules/${existing._id}`
      : `${API}/modules`;

    fetch(url, {
      method,
      headers: {
        'Content-Type': 'application/json',
        username: 'admin',
        password: 'admin'
      },
      body: JSON.stringify(payload)
    })
      .then(res => {
        if (!res.ok) throw new Error('Failed to save module');
        return res.json();
      })
      .then(() => {
        onCreated();
        onClose();
        setName('');
      })
      .catch(err => alert(err.message));
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth>
      <DialogTitle>{existing ? 'Edit Module' : 'Add New Module'}</DialogTitle>
      <DialogContent sx={{ display: 'flex', flexDirection: 'column', gap: 2, mt: 1 }}>
        <TextField
          label="Module Name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          fullWidth
        />
        {/* Route is auto-generated and hidden from user */}
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>Cancel</Button>
        <Button variant="contained" onClick={handleSubmit}>
          {existing ? 'Save Changes' : 'Create'}
        </Button>
      </DialogActions>
    </Dialog>
  );
}
