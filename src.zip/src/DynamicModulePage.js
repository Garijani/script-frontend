// // import React, { useEffect, useState } from 'react';
// // import { Box, Typography, CircularProgress, Button } from '@mui/material';
// // import { Add } from '@mui/icons-material';
// // import { useParams } from 'react-router-dom';
// // import AddItemModal from './AddItemModal';
// // import EquipmentTable from './EquipmentTable';

// // const MODULE_API = process.env.REACT_APP_API + '/modules';
// // const INV_API    = process.env.REACT_APP_API + '/api/inventory';

// // export default function DynamicModulePage() {
// //   const { moduleName } = useParams();
// //   const [module, setModule]     = useState(null);
// //   const [items, setItems]       = useState([]);
// //   const [loading, setLoading]   = useState(true);
// //   const [showAddModal, setShowAddModal] = useState(false);

// //   // Initial load of schema + data
// //   const fetchData = async () => {
// //     setLoading(true);
// //     try {
// //       const mod = await fetch(
// //         `${MODULE_API}/route/${moduleName}`,
// //         { headers: { username: 'admin', password: 'admin' } }
// //       ).then(r => r.json());
// //       setModule(mod);

// //       const inv = await fetch(
// //         `${INV_API}?moduleName=${moduleName}`,
// //         { headers: { username: 'admin', password: 'admin' } }
// //       ).then(r => r.json());
// //       setItems(inv);
// //     } catch (e) {
// //       console.error(e);
// //     } finally {
// //       setLoading(false);
// //     }
// //   };

// //   useEffect(() => { fetchData(); }, [moduleName]);

// //   // Delete row: update local state then delete on server
// //   const handleDeleteRow = async id => {
// //     setItems(prev => prev.filter(item => item._id !== id));
// //     try {
// //       await fetch(`${INV_API}/${id}`, { method: 'DELETE', headers: { username: 'admin', password: 'admin' } });
// //     } catch (err) {
// //       console.error('Failed to delete:', err);
// //       // optionally refetch or show error
// //     }
// //   };

// //   // Inline cell edit: update local state seamlessly, then patch server
// //   const handleEditCell = async (rowId, col, newValue) => {
// //     setItems(prev =>
// //       prev.map(item =>
// //         item._id === rowId
// //           ? { ...item, fields: { ...item.fields, [col]: newValue } }
// //           : item
// //       )
// //     );
// //     const item = items.find(i => i._id === rowId);
// //     const updatedFields = { ...item.fields, [col]: newValue };
// //     try {
// //       await fetch(`${INV_API}/${rowId}`, {
// //         method: 'PUT',
// //         headers: { 'Content-Type': 'application/json', username: 'admin', password: 'admin' },
// //         body: JSON.stringify({ fields: updatedFields })
// //       });
// //     } catch (err) {
// //       console.error('Failed to save edit:', err);
// //       // optionally rollback to previous state
// //     }
// //   };

// //   // Column schema mutations (no change)
// //   const patchFields = async updated => {
// //     setModule(prev => ({ ...prev, fieldsSchema: updated }));
// //     try {
// //       await fetch(`${MODULE_API}/${module._id}/fields`, {
// //         method: 'PATCH',
// //         headers: { 'Content-Type': 'application/json', username: 'admin', password: 'admin' },
// //         body: JSON.stringify({ fieldsSchema: updated })
// //       });
// //     } catch (err) {
// //       console.error('Failed to update schema:', err);
// //     }
// //   };
// //   const handleDeleteColumn = idx => { patchFields(module.fieldsSchema.filter((_, i) => i !== idx)); };
// //   const handleAddColumnLeft = idx => {
// //     const name = `Column ${module.fieldsSchema.length + 1}`;
// //     patchFields([
// //       ...module.fieldsSchema.slice(0, idx), name, ...module.fieldsSchema.slice(idx)
// //     ]);
// //   };
// //   const handleAddColumnRight = idx => {
// //     const name = `Column ${module.fieldsSchema.length + 1}`;
// //     patchFields([
// //       ...module.fieldsSchema.slice(0, idx + 1), name, ...module.fieldsSchema.slice(idx + 1)
// //     ]);
// //   };
// //   const handleRenameColumn = (idx, newName) => {
// //     const u = module.fieldsSchema.slice();
// //     u[idx] = newName;
// //     patchFields(u);
// //   };

// //   if (loading || !module) {
// //     return <Box textAlign="center" mt={8}><CircularProgress /></Box>;
// //   }

// //   // Map items to row shape
// //   const rows = items.map(i => ({ id: i._id, ...i.fields }));

// //   return (
// //     <Box p={3}>
// //       <Typography variant="h4" gutterBottom>📋 {module.name} Module</Typography>
// //       <Button
// //         variant="contained"
// //         startIcon={<Add />}
// //         onClick={() => setShowAddModal(true)}
// //         sx={{ mb: 2 }}
// //       >
// //         Add Item
// //       </Button>

// //       <EquipmentTable
// //         columns={module.fieldsSchema}
// //         rows={rows}
// //         onDeleteRow={handleDeleteRow}
// //         onDeleteColumn={handleDeleteColumn}
// //         onAddColumnLeft={handleAddColumnLeft}
// //         onAddColumnRight={handleAddColumnRight}
// //         onRenameColumn={handleRenameColumn}
// //         onEditCell={handleEditCell}
// //       />

// //       <AddItemModal
// //         open={showAddModal}
// //         onClose={() => setShowAddModal(false)}
// //         fieldsSchema={module.fieldsSchema}
// //         onSave={async values => {
// //           setShowAddModal(false);
// //           // optimistic add
// //           const res = await fetch(INV_API, {
// //             method: 'POST',
// //             headers: { 'Content-Type': 'application/json', username: 'admin', password: 'admin' },
// //             body: JSON.stringify({ moduleId: module._id, fields: values })
// //           });
// //           const newItem = await res.json();
// //           setItems(prev => [...prev, newItem]);
// //         }}
// //       />
// //     </Box>
// //   );
// // }




// // frontend/src/components/DynamicModulePage.js
// import React, { useEffect, useState } from 'react';
// import { Box, Typography, CircularProgress, Button } from '@mui/material';
// import { Add } from '@mui/icons-material';
// import { useParams } from 'react-router-dom';
// import AddItemModal from './AddItemModal';
// import EquipmentTable from './EquipmentTable';
// import api from './api';  // ← your axios instance

// export default function DynamicModulePage() {
//   const { moduleName } = useParams();
//   const [module, setModule] = useState(null);
//   const [items, setItems] = useState([]);
//   const [loading, setLoading] = useState(true);
//   const [showAddModal, setShowAddModal] = useState(false);

//   const fetchData = async () => {
//     setLoading(true);
//     try {
//       // 1) Get module schema
//       const { data: mod } = await api.get(`/modules/route/${moduleName}`);
//       setModule(mod);

//       // 2) Get items (no extra `/api` here)
//       const { data: inv } = await api.get(
//         `/inventory?moduleName=${moduleName}`
//       );
//       setItems(inv);
//     } catch (err) {
//       console.error('Failed to fetch module or inventory:', err);
//     } finally {
//       setLoading(false);
//     }
//   };

//   useEffect(() => {
//     fetchData();
//   }, [moduleName]);

//   // Delete row locally + server
//   const handleDeleteRow = async (id) => {
//     setItems(prev => prev.filter(item => item._id !== id));
//     try {
//       await api.delete(`/inventory/${id}`);
//     } catch (err) {
//       console.error('Failed to delete item:', err);
//       // Optionally re-fetch or show error toast
//     }
//   };

//   // Inline cell edit: update local then patch server
//   const handleEditCell = async (rowId, col, newValue) => {
//     setItems(prev =>
//       prev.map(item =>
//         item._id === rowId
//           ? { ...item, fields: { ...item.fields, [col]: newValue } }
//           : item
//       )
//     );
//     try {
//       await api.put(
//         `/inventory/${rowId}`,
//         { fields: { ...items.find(i => i._id === rowId).fields, [col]: newValue } }
//       );
//     } catch (err) {
//       console.error('Failed to save edit:', err);
//       // Optionally rollback state
//     }
//   };

//   // Column schema mutations
//   const patchFields = async (updated) => {
//     setModule(prev => ({ ...prev, fieldsSchema: updated }));
//     try {
//       await api.patch(`/modules/${module._id}/fields`, {
//         fieldsSchema: updated,
//       });
//     } catch (err) {
//       console.error('Failed to update schema:', err);
//     }
//   };
//   const handleDeleteColumn = idx =>
//     patchFields(module.fieldsSchema.filter((_, i) => i !== idx));
//   const handleAddColumnLeft = idx => {
//     const name = `Column ${module.fieldsSchema.length + 1}`;
//     patchFields([
//       ...module.fieldsSchema.slice(0, idx),
//       name,
//       ...module.fieldsSchema.slice(idx),
//     ]);
//   };
//   const handleAddColumnRight = idx => {
//     const name = `Column ${module.fieldsSchema.length + 1}`;
//     patchFields([
//       ...module.fieldsSchema.slice(0, idx + 1),
//       name,
//       ...module.fieldsSchema.slice(idx + 1),
//     ]);
//   };
//   const handleRenameColumn = (idx, newName) => {
//     const u = [...module.fieldsSchema];
//     u[idx] = newName;
//     patchFields(u);
//   };

//   if (loading || !module) {
//     return (
//       <Box textAlign="center" mt={8}>
//         <CircularProgress />
//       </Box>
//     );
//   }

//   // Map items to DataGrid rows
//   const rows = items.map(i => ({ id: i._id, ...i.fields }));

//   return (
//     <Box p={3}>
//       <Typography variant="h4" gutterBottom>
//         📋 {module.name} Module
//       </Typography>

//       <Button
//         variant="contained"
//         startIcon={<Add />}
//         onClick={() => setShowAddModal(true)}
//         sx={{ mb: 2 }}
//       >
//         Add Item
//       </Button>

//       <EquipmentTable
//         columns={module.fieldsSchema}
//         rows={rows}
//         onDeleteRow={handleDeleteRow}
//         onDeleteColumn={handleDeleteColumn}
//         onAddColumnLeft={handleAddColumnLeft}
//         onAddColumnRight={handleAddColumnRight}
//         onRenameColumn={handleRenameColumn}
//         onEditCell={handleEditCell}
//       />

//       <AddItemModal
//         open={showAddModal}
//         onClose={() => setShowAddModal(false)}
//         fieldsSchema={module.fieldsSchema}
//         onSave={async (values) => {
//           setShowAddModal(false);
//           try {
//             const { data: newItem } = await api.post('/inventory', {
//               moduleId: module._id,
//               fields: values,
//             });
//             setItems(prev => [...prev, newItem]);
//           } catch (err) {
//             console.error('Failed to add item:', err);
//           }
//         }}
//       />
//     </Box>
//   );
// }


// frontend/src/components/DynamicModulePage.js
import React, { useEffect, useState } from 'react';
import { Box, Typography, CircularProgress, Button } from '@mui/material';
import { Add } from '@mui/icons-material';
import { useParams } from 'react-router-dom';
import AddItemModal from './AddItemModal';
import EquipmentTable from './EquipmentTable';
import api from './api';

export default function DynamicModulePage() {
  const { moduleName } = useParams();
  const [module, setModule] = useState(null);
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showAddModal, setShowAddModal] = useState(false);

  const fetchData = async () => {
    setLoading(true);
    try {
      const { data: mod } = await api.get(`/modules/route/${moduleName}`);
      setModule(mod);

      const { data: inv } = await api.get(`/inventory?moduleName=${moduleName}`);
      setItems(inv);
    } catch (err) {
      console.error('Failed to fetch module or inventory:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [moduleName]);

  const handleDeleteRow = async (id) => {
    setItems(prev => prev.filter(item => item._id !== id));
    try {
      await api.delete(`/inventory/${id}`);
    } catch (err) {
      console.error('Failed to delete item:', err);
    }
  };

  const handleEditCell = async (rowId, col, newValue) => {
    setItems(prev =>
      prev.map(item =>
        item._id === rowId
          ? { ...item, fields: { ...item.fields, [col]: newValue } }
          : item
      )
    );
    try {
      await api.put(`/inventory/${rowId}`, {
        fields: { ...items.find(i => i._id === rowId).fields, [col]: newValue }
      });
    } catch (err) {
      console.error('Failed to save edit:', err);
    }
  };

  const patchFields = async (updated) => {
    setModule(prev => ({ ...prev, fieldsSchema: updated }));
    try {
      await api.patch(`/modules/${module._id}/fields`, {
        fieldsSchema: updated
      });
    } catch (err) {
      console.error('Failed to update schema:', err);
    }
  };

  const handleDeleteColumn = idx =>
    patchFields(module.fieldsSchema.filter((_, i) => i !== idx));
  const handleAddColumnLeft = idx => {
    const name = `Column ${module.fieldsSchema.length + 1}`;
    patchFields([
      ...module.fieldsSchema.slice(0, idx),
      name,
      ...module.fieldsSchema.slice(idx)
    ]);
  };
  const handleAddColumnRight = idx => {
    const name = `Column ${module.fieldsSchema.length + 1}`;
    patchFields([
      ...module.fieldsSchema.slice(0, idx + 1),
      name,
      ...module.fieldsSchema.slice(idx + 1)
    ]);
  };
  const handleRenameColumn = (idx, newName) => {
    const updated = [...module.fieldsSchema];
    updated[idx] = newName;
    patchFields(updated);
  };

  if (loading || !module) {
    return (
      <Box textAlign="center" mt={8}>
        <CircularProgress />
      </Box>
    );
  }

  // 🔧 Ensure 'Accessories' column is present
  const fieldsSchemaWithAccessories = module.fieldsSchema.includes('Accessories')
    ? module.fieldsSchema
    : [...module.fieldsSchema, 'Accessories'];

  // 🔧 Map rows and insert Accessories names
  // const rows = items.map(item => ({
  //   id: item._id,
  //   ...item.fields,
  //   Accessories: item.accessories?.map(acc => acc.fields?.['Item Name']).join(', ') || ''
  // }));

  // const rows = items.map(i => ({
  //   id: i._id,
  //   ...((i.fields?.values && typeof i.fields.values === 'object') ? i.fields.values : i.fields)
  // }));
  
  const rows = items.map(i => {
    const values = i.fields?.values || i.fields || {};
    const accessories = i.fields?.accessories || [];
  
    return {
      id: i._id,
      ...values,
      Accessories: accessories.map(a => `${a.name}`).join(', ')
    };
  });
  

  return (
    <Box p={3}>
      <Typography variant="h4" gutterBottom>
        📋 {module.name} Module
      </Typography>

      <Button
        variant="contained"
        startIcon={<Add />}
        onClick={() => setShowAddModal(true)}
        sx={{ mb: 2 }}
      >
        Add Item
      </Button>

      <EquipmentTable
        columns={fieldsSchemaWithAccessories}
        rows={rows}
        onDeleteRow={handleDeleteRow}
        onDeleteColumn={handleDeleteColumn}
        onAddColumnLeft={handleAddColumnLeft}
        onAddColumnRight={handleAddColumnRight}
        onRenameColumn={handleRenameColumn}
        onEditCell={handleEditCell}
      />

      <AddItemModal
        open={showAddModal}
        onClose={() => setShowAddModal(false)}
        fieldsSchema={module.fieldsSchema}
        onSave={async (values) => {
          setShowAddModal(false);
          try {
            const { data: newItem } = await api.post('/inventory', {
              moduleId: module._id,
              fields: values,
            });
            setItems(prev => [...prev, newItem]);
          } catch (err) {
            console.error('Failed to add item:', err);
          }
        }}
      />
    </Box>
  );
}
