//frontend/src/components/Login.js


import React, { useState } from 'react';
import { Box, TextField, Button, Typography, Alert, useTheme, Paper } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import api from '../api';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();
  const theme = useTheme(); // ✅ detect dark/light mode

  const handleLogin = async (e) => {
    e.preventDefault();
    setError('');

    try {
      const response = await api.post('/auth/login', { email, password });

      localStorage.setItem('token', response.data.token);
      localStorage.setItem('user', JSON.stringify(response.data.user));

      console.log('User logged in:', response.data.user);
      navigate('/');
    } catch (err) {
      console.error('Login error:', err.response?.data || err.message);
      setError(err.response?.data?.message || 'Login failed. Please check your credentials.');
    }
  };

  // return (
  //   <Box
  //     sx={{
  //       display: 'flex',
  //       justifyContent: 'center',
  //       alignItems: 'center',
  //       height: '100vh',
  //       bgcolor: theme.palette.background.default, // ✅ respect theme
  //     }}
  //   >
  //     <Box
  //       sx={{
  //         width: '100%',
  //         maxWidth: 400,
  //         p: 4,
  //         bgcolor: theme.palette.background.paper, // ✅ adapt to dark/light
  //         borderRadius: 2,
  //         boxShadow: 3,
  //       }}
  //     >
  //       <Typography variant="h4" align="center" gutterBottom>
  //         Login
  //       </Typography>

  //       <form onSubmit={handleLogin}>
  //         <TextField
  //           label="Email"
  //           variant="outlined"
  //           fullWidth
  //           margin="normal"
  //           type="email"
  //           value={email}
  //           onChange={(e) => setEmail(e.target.value)}
  //           required
  //         />

  //         <TextField
  //           label="Password"
  //           type="password"
  //           variant="outlined"
  //           fullWidth
  //           margin="normal"
  //           value={password}
  //           onChange={(e) => setPassword(e.target.value)}
  //           required
  //         />

  //         {error && (
  //           <Alert severity="error" sx={{ mt: 2 }}>
  //             {error}
  //           </Alert>
  //         )}

  //         <Button
  //           type="submit"
  //           variant="contained"
  //           color="primary"
  //           fullWidth
  //           sx={{ mt: 2 }}
  //         >
  //           Login
  //         </Button>
  //       </form>
  //     </Box>
  //   </Box>
  // );

  return (
    <Box
      sx={{
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        height: '100vh',
        bgcolor: 'background.default',
      }}
    >
      <Paper
        sx={{
          p: 4,
          borderRadius: 4,
          width: 350,
          bgcolor: 'background.paper',
          boxShadow: 3,
        }}
      >
        <Typography variant="h5" fontWeight="bold" align="center" gutterBottom>
          Login
        </Typography>
  
        <TextField
          fullWidth
          margin="normal"
          label="Email *"
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
        <TextField
          fullWidth
          margin="normal"
          label="Password *"
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
  
        <Button
          fullWidth
          variant="contained"
          sx={{ mt: 2, bgcolor: '#90caf9' }}
          onClick={handleLogin}
        >
          LOGIN
        </Button>
  
        {/* ✅ Register Link */}
        <Typography variant="body2" align="center" sx={{ mt: 2 }}>
          Don’t have an account?{' '}
          <Button variant="text" onClick={() => navigate('/register')}>
            Register
          </Button>
        </Typography>
      </Paper>
    </Box>
  );
  
}
